document.getElementById("logo-input").addEventListener("change", function(event) {
    let reader = new FileReader();
    reader.onload = function() {
        let logoPreview = document.getElementById("logo-preview");
        logoPreview.src = reader.result; // Show uploaded image
    };
    reader.readAsDataURL(event.target.files[0]);
});
function adminLogin() {
    let username = document.getElementById("admin-username").value;
    let password = document.getElementById("admin-password").value;

    // Set the correct login credentials
    if (username === "adkconsultancy" && password === "a@0912490990") {
        document.getElementById("admin-login").style.display = "none"; // Hide login form
        document.getElementById("logo-upload-container").style.display = "block"; // Show upload section
    } else {
        alert("Invalid credentials! Only the website owner can upload a logo.");
    }
}

// Handle logo upload
document.getElementById("logo-input").addEventListener("change", function(event) {
    let reader = new FileReader();
    reader.onload = function() {
        let logoPreview = document.getElementById("logo-preview");
        logoPreview.src = reader.result; // Show uploaded image
    };
    reader.readAsDataURL(event.target.files[0]);
});
